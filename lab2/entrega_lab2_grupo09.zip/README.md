## Como correr el código

Para correr el codigo tienen que descargar las librerias que se encuentran en el requirements.txt, luego ejecutan el comando "python bayesiano.py" y empezará a correr el código.

## Aclaración
Se adjunta una carpeta images con imágenes de los plots que se visualizan al correr el código para referenciarlos de esta forma en el informe.